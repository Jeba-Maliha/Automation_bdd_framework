package Utility;

public class Portals {

    public static class dev {

        public String clubswan() {
            String url = "member.dev.clubswan.com";
            return url;
        }
        public String blockchainfunding() {
            String url = "dev.bcfclubmembers.com/";
            return url;
        }

        public String gsl() {
            String url = "dev.gslifestylecard.com";
            return url;
        }

        public String aurae() {
            String url = "member.dev.auraelifestyle.com";
            return url;
        }

        public String plcu() {
            String url = "dev.plcumember.com";
            return url;
        }

        public String hodl() {
            String url = "dev.hodl.clubswan.com";
            return url;
        }

        public String clubPheonix() {
            String url = "dev.clubphoenixmembers.com";
            return url;
        }

        public String coinovy() {
            String url = "dev.coinovymembers.com";
            return url;
        }

        public String cashft() {
            String url = "dev.cashftmembers.com";
            return url;
        }

        public String earnGuild() {
            String url = "dev.earnguildcard.com";
            return url;
        }

        public String endPoint() {
            String url = "dev.endpointmembers.com";
            return url;
        }

        public String midasClub() {
            String url = "dev.midas.clubswan.com";
            return url;
        }

        public String suisseCapital() {
            String url = "dev.wallet-suissecapital.com";
            return url;
        }
        public String pagosRD() {
            String url = "dev.pagosrd.com";
            return url;
        }

        public String infinity() {
            String url = "dev.infinityclubcardmembers.com";
            return url;
        }

        public String milio() {
            String url = "dev.miliomembers.com";
            return url;
        }

        public String lyopay() {
            String url = "dev.lyopaymembers.com";
            return url;
        }

        public String neuroTrade() {
            String url = "dev.neurotrademember.com";
            return url;
        }

        public String noe() {
            String url = "dev.noemembers.com";
            return url;
        }

        public String arduPay() {
            String url = "dev.ardupaymembers.com";
            return url;
        }

        public String aubitPay() {
            String url = "dev.aubitpaymembers.com";
            return url;
        }

        public String amWallet() {
            String url = "dev.amcardmembers.com";
            return url;
        }
        public String trivi() {
            String url = "dev.trivi.clubswan.com";
            return url;
        }
        public String worldClub() {
            String url = "dev.wallet-worldclub.com";
            return url;
        }
        public String dreamWallet() {
            String url = "dev.dreamwallet.clubswan.com";
            return url;
        }
        public String aKashX() {
            String url = "dev.akashx.clubswan.com";
            return url;
        }
        public String freeBay() {
            String url = "dev.freebayconcierge.com";
            return url;
        }
        public String owlLifestyle() {
            String url = "dev.owl-lifestyle.com";
            return url;
        }
        public String ladgerScore() {
            String url = "dev.ledgerscorecard.com";
            return url;
        }

        public String debtboxDv() {
            String url = "dev.thedebtboxmembers.com";
            return url;
        }

        //
    }

    public static class tst {

        public String clubswan() {
            String url = "member.tst.clubswan.com";
            return url;
        }
        public String blockchainfunding() {
            String url = "sandbox.bcfclubmembers.com/";
            return url;
        }

        public String gsl() {
            String url = "tst.gslifestylecard.com";
            return url;
        }

        public String aurae() {
            String url = "member.tst.auraelifestyle.com";
            return url;
        }

        public String plcu() {
            String url = "sandbox.plcumember.com";
            return url;
        }

        public String hodl() {
            String url = "sandbox.hodl.clubswan.com";
            return url;
        }

        public String clubPheonix() {
            String url = "sandbox.clubphoenixmembers.com";
            return url;
        }

        public String coinovy() {
            String url = "sandbox.coinovymembers.com";
            return url;
        }

        public String cashft() {
            String url = "sandbox.cashftmembers.com";
            return url;
        }

        public String earnGuild() {
            String url = "sandbox.earnguildcard.com";
            return url;
        }

        public String endPoint() {
            String url = "sandbox.endpointmembers.com";
            return url;
        }

        public String midasClub() {
            String url = "tst.midas.clubswan.com";
            return url;
        }

        public String suisseCapital() {
            String url = "tst.wallet-suissecapital.com";
            return url;
        }
        public String pagosRD() {
            String url = "sandbox.pagosrd.com";
            return url;
        }

        public String infinity() {
            String url = "sandbox.infinityclubcardmembers.com";
            return url;
        }

        public String milio() {
            String url = "sandbox.miliomembers.com";
            return url;
        }

        public String lyopay() {
            String url = "sandbox.lyopaymembers.com";
            return url;
        }

        public String neuroTrade() {
            String url = "sandbox.neurotrademember.com";
            return url;
        }

        public String noe() {
            String url = "sandbox.noemembers.com";
            return url;
        }

        public String arduPay() {
            String url = "sandbox.ardupaymembers.com";
            return url;
        }

        public String aubitPay() {
            String url = "sandbox.aubitpaymembers.com";
            return url;
        }

        public String amWallet() {
            String url = "sandbox.amcardmembers.com";
            return url;
        }
        public String trivi() {
            String url = "tst.trivi.clubswan.com";
            return url;
        }
        public String worldClub() {
            String url = "tst.wallet-worldclub.com";
            return url;
        }
        public String dreamWallet() {
            String url = "tst.dreamwallet.clubswan.com";
            return url;
        }
        public String aKashX() {
            String url = "tst.akashx.clubswan.com";
            return url;
        }
        public String freeBay() {
            String url = "tst.freebayconcierge.com";
            return url;
        }
        public String owlLifestyle() {
            String url = "sandbox.owl-lifestyle.com";
            return url;
        }
        public String ladgerScore() {
            String url = "sandbox.ledgerscorecard.com";
            return url;
        }

        public String debtbox() {
            String url = "sandbox.thedebtboxmembers.com";
            return url;
        }



    }
}

