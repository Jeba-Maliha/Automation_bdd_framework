package Utility;

public class BaseCredentials {

    public static String BaseEmailList() {
//        String Email="clubswan_non-us_devqyxx@mailinator.com";
//        String Email="rashed.mahmud@springrain.io";//Rashed
          // String Email = "stalin.neurotrade.tst.1@mailinator.com"; //Neotrade
//        String Email="clubswan_us_dev_marina@mailinator.com";
//        String Email = "test_PLCU_dev@mailinator.com";
//        String Email = "clubswan_us_tst_rtl_18@mailinator.com"; //cs tst
//        String Email = "test_clubswan_US_tst@grr.la"; //cs tst
//        String Email="stalin.icc.tst.3@mailinator.com";//Stalin
        String Email="clubswan_non-us_tst_wiley@mailinator.com"; //php portal
//          String Email="infinity_uk_tst_aut_angie@mailinator.com";

//          String Email="hodl_us_dev_d9@mailinator.com";
//        String Email="clubswan_fra_dev_d31@mailinator.com";
        //String Email="aurae_us_tst_t7@mailinator.com"; //Auriy
        return Email;
    }

    public static String BaseOTPList()
    {
//        String secretKey = "ROTBDJNQRXO3NUJMH5E37ZWBEA";
//        String secretKey = "I3P7OM4QWVTAJMRFKWU5YCPB24"; //cs tst 18
//        String secretKey = "I4BDIRMSMJUR6CWSEZ2DMF2I4E"; //cs dev
//        String secretKey = "E2KW4F4D3P656NV7HYXVMSRSLY"; //PLC dev
//        String secretKey = "XCFX7E3B6XFXSGKGMGRPQAIIEQ"; //rifa
//        String secretKey = "GMN2ETS35OSX575RNQFKLA3A5Y"; //rashed
//        String secretKey="MFV5OMU7KCCKQN6SDJESMD3DKE"; //Club Swan
//        String secretKey = "MW73YZSM5Q4YWTBGCY7X2ZWYXU";//Stalin
//        String secretKey="ICQ3OLQHPQAEU7G2QHUK3DF5E4"; //Php Portal
//        String secretKey = "EXVXUQPBJMVWC7RUWEL2BIUOKI";//Php Portal
//        String secretKey="ZNPOHASCFTKK7W3YVQXAZY4XOE";//HODL
//        String secretKey = "XEWKO5TR7VSOZQTCB4TC2ZQBXY";
        //String secretKey="RAQ36UGZ4N6ELJMKT6YVI6WQDU";
        // String secretKey = "6UNVY5GUBZIYMVIW4UZBLXTGO4";//Neotrade
        String secretKey="2IALA7MZI24LTUFY7ABYX5W7PA"; //Auriy
        return secretKey;
    }

    public static String BasePassword(){
        String Password = "Tt123#123#";
        return Password;
    }
}
