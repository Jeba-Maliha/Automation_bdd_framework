package Utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SubscriptionBody {

    public static String Currency;
    public static String PlanId;


    public static String currency() {
        String PortalEmail= Random_data.signUpEmail();
        Currency =PortalEmail;
        return Currency;
    }

    public static String planId() {
        String pass= Random_data.pass();
        PlanId =pass;
        return PlanId;
    }

    public String subscription_body() throws Exception {
        currency();
        planId();


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        String subscriptionBody = "{\n" +
                "\t\"currency\":\""+Currency+"\",\n" +
                "    \"planId\": \""+PlanId+"\",\n" +
                    "}";

//        System.out.println("Email:  " + Portal_Email + " " + dtf.format(now));
//        String Data ="Email : "+ Portal_Email + "  "+dtf.format(now);
//
//        File files = new File("Email/PortalEmail.txt");
//        FileWriter fw = new FileWriter(files,true);
//        BufferedWriter bw = new BufferedWriter(fw);
//        bw.write(Data);
//        bw.newLine();
//        bw.close();

        return subscriptionBody;
    }

}
