package Utility;

import java.io.FileInputStream;
import java.util.Properties;

public class BaseCredentials {

    public static String BaseEmailList() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/config.properties");
        prop.load(file);
        String Email = prop.getProperty("Email");
        return Email;
    }

    public static String BaseOTPList() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/config.properties");
        prop.load(file);
        String secretKey = prop.getProperty("secretKey");
        return secretKey;
    }

    public static String BasePassword() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/config.properties");
        prop.load(file);
        String Password = prop.getProperty("Password");
        return Password;
    }

    public static String testEnv() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/config.properties");
        prop.load(file);
        String Environment = prop.getProperty("Environment");
        return Environment;
    }
    public static String invoiceLink() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String InvoiceLink = prop.getProperty("InvoiceLink");
        return InvoiceLink;
    }
    public static String partnerEnv() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String Environment = prop.getProperty("Environment");
        return Environment;
    }
    public static String invoiceCurrency() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String Currency = prop.getProperty("Currency");
        return Currency;
    }

    public static String invoiceAmount() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String Amount = prop.getProperty("Amount");
        return Amount;
    }

    public static String pgwKey() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String Key = prop.getProperty("Key");
        return Key;
    }

    public static String pgwToken() throws Exception {

        Properties prop = new Properties();
        FileInputStream file;
        file = new FileInputStream("./src/test/resources/Partner_Payment_Key_Token.properties");
        prop.load(file);
        String Token = prop.getProperty("Token");
        return Token;
    }

}
