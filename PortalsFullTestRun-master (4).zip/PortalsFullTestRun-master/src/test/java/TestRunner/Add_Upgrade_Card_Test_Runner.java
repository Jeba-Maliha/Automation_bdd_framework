package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features",glue = "StepDefinations",
        tags="@addCard_ult_wallet_Payment",
        plugin ={"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","rerun:target/failedrerun.txt"},
        monochrome = true)
public class Add_Upgrade_Card_Test_Runner {
}

/* ::::::::::::::::::::::::::::::::::::Note for tags::::::::::::::::::::::::::::::::::
For Secreat Add/Upgrade card:::::
     @addCard_us  ------> Add First tier card and then upgrade card to second and tier functionality  for US members will run by this tag.
     @addCard_non_us  ------> Add First tier card and then upgrade card to second and tier functionality  for Non-US members will run by this tag.

For Ultima Upgrade card:::::
    @addCard_ult_Card_Payment ------> Upgrade card using debit/credit card for Non-US members will run by this tag.(This will not work for Seacret)
    @addCard_ult_wallet_Payment ------> Upgrade card using wallet for Non-US members will run by this tag.(This will not work for Seacret)
*/








