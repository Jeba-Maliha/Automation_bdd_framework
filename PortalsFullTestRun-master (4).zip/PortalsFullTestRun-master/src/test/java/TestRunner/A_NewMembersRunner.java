package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features/A.NewMembers/NewMembers.feature",glue = "StepDefinations",
        tags="@new_member_acc or @all_non_us",
        plugin ={"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","rerun:target/failedrerun.txt"},
        monochrome = true)
public class A_NewMembersRunner {
}

/* ::::::::::::::::::::::::::::::::::::Note for tags::::::::::::::::::::::::::::::::::
1. @new_member_dc_us
 ---> popup-topup, virtual card purchase and activate using debit/credit card; m2m beneficiary creation; phy card activation scenarios for US members.
2. @new_member_dc_non_us
 ---> popup-topup, virtual card purchase and activate using debit/credit card; m2m beneficiary creation; phy card activation scenarios for US members.
3. @new_member_acc
 ---> popup-topup using debit/credit card; virtual card purchase and activate using e-Wallet; m2m beneficiary creation; phy card activation scenarios for US members.

*/
