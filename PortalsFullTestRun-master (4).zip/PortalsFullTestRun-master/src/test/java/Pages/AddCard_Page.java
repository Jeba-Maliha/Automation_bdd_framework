package Pages;


import Utility.BaseData;
import Utility.UserProfile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.DecimalFormat;
import java.util.List;


/**
 * @author Nahid
 */
public class AddCard_Page {
    public String cardPrice;
    public String shippingPrice;
    public String payShippingPrice;
    public String payableCardPrice;
    public String payTodayPrice;
    public String discountRate;
    @FindBy(xpath = "//span[text()='Cards']")
    public WebElement cardMenu;
    @FindBy(xpath = "//div/p")
    public WebElement vCardPage;
    @FindBy(xpath = "//span[contains(text(),'Add Card')]")
    public WebElement addCard;
    @FindBy(xpath = "//span[contains(text(),'Upgrade Card')]")
    public WebElement upgrdCard;
    @FindBy(xpath = "//div[text()='Card Currency']")
    public WebElement cardCurrency;
    @FindBy(xpath = "//div[text()='Card Currency']/../div[2]/div/div")
    public WebElement curDropDown;
    @FindBy(xpath = "//span[text()='USD']")
    public WebElement curUSD;
    @FindBy(xpath = "//span[text()='GBP']")
    public WebElement curGBP;
    @FindBy(xpath = "//span[text()='EUR']")
    public WebElement curEUR;
    @FindBy(xpath = "//span[text()='Card Design']")
    public WebElement cardDesign;
    @FindBy(xpath = "//section[@id='slider']/label/span")
    public WebElement collectPrice;
    @FindBy(xpath = "//label[@id='slide1']/img")
    public WebElement cardPlastic;
    @FindBy(xpath = "//label[@id='slide1']/span")
    public WebElement cardNamePls;
    @FindBy(xpath = "//label[@id='slide2']/img")
    public WebElement cardAluminium;
    @FindBy(xpath = "//label[@id='slide2']/span")
    public WebElement cardNameAlu;
    @FindBy(xpath = "//label[@id='slide3']/img")
    public WebElement cardSteel;
    @FindBy(xpath = "//label[@id='slide3']/span")
    public WebElement cardNameSteel;
    //*********second tier**********
    @FindBy(xpath = "//label[@id='slide1']/img")
    public WebElement cardAluminium1;
    @FindBy(xpath = "//label[@id='slide1']/span")
    public WebElement cardNameAlu1;
    @FindBy(xpath = "//label[@id='slide2']/img")
    public WebElement cardSteel1;
    @FindBy(xpath = "//label[@id='slide2']/span")
    public WebElement cardNameSteel1;
    //*********3rd tier**********
    @FindBy(xpath = "//label[@id='slide1']/img")
    public WebElement cardSteel2;
    @FindBy(xpath = "//label[@id='slide1']/span")
    public WebElement cardNameSteel2;
    @FindBy(xpath = "//label[text()='Shipping ']")
    public WebElement shipping;
    @FindBy(xpath = "//label[text()='Shipping ']/../div/div/div")
    public WebElement shipDropDown;
    @FindBy(xpath = "//li[text()='Standard Mail (Global) - (+ $5.95)']")
    public WebElement shippingStander;
    @FindBy(xpath = "//li[text()='Expedited - (+ $119.95)']")
    public WebElement shippingExped;
    @FindBy(xpath = "//li[text()='Expedited - (+ €110.95)']")
    public WebElement shippingExpedUltima;
    @FindBy(xpath = "//span[text()='Pay today']/../span[2]")
    public WebElement payToday;
    @FindBy(xpath = "//span[text()='Card']/../span[2]")
    public WebElement payCard;
    @FindBy(xpath = "//span[text()='Shipping']/../span[2]")
    public WebElement payShipping;
    @FindBy(xpath = "//span[text()='Discount']/../span[2]")
    public WebElement disApply;
    @FindBy(xpath = "//span[text()='Continue']")
    public WebElement continueBtn;
    @FindBy(xpath = "(//button[@type='button'])[3]/../h4")
    public WebElement cardName;
    ///Next page
    @FindBy(xpath = "(//button[@type='button'])[3]")
    public WebElement crossBtn;
    @FindBy(xpath = "(//button[@type='button'])[4]")
    public WebElement changeBtn;
    @FindBy(xpath = "//label[text()='Apply Discount Code (If applicable)']")
    public WebElement discountTitle;
    @FindBy(xpath = "//input[@name='discountCode']")
    public WebElement discountCode;
    @FindBy(xpath = "(//button[@type='button'])[5]")
    public WebElement applyBtn;
    @FindBy(xpath = "//label[text()='Payment Method']")
    public WebElement paymentTitle;
    @FindBy(xpath = "//label[text()='Payment Method']/../div/div")
    public WebElement paymentMethod;
    @FindBy(xpath = "//li[@data-value='eWallet']")
    public WebElement paymentAccount;
    @FindBy(xpath = "//div[@class='details-container']/../div/div[1]")
    public WebElement ewallet;
    @FindBy(xpath = "//p[text()='Available balance']/../p[2]")
    public WebElement balance;
    @FindBy(xpath = "//p[text()='To be debit']/../p[2]")
    public WebElement debitAmt;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]/ul/li[1]")
    public WebElement selectEW1;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]/ul/li[2]")
    public WebElement selectEW2;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]/ul/li[3]")
    public WebElement selectEW3;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]/ul/li[4]")
    public WebElement selectEW4;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]/ul/li[5]")
    public WebElement selectEW5;
    @FindBy(xpath = "//*[@id=\"menu-\"]/div[3]")
    public WebElement selectEW;
    @FindBy(xpath = "//li[@data-value='card']")
    public WebElement paymentCard;
    @FindBy(xpath = "//h4[text()='Shipping']")
    public WebElement shippingTitle;
    @FindBy(xpath = "//h4[text()='Shipping']/../div")
    public WebElement shipMetName;
    @FindBy(xpath = "//span[text()='Confirm']")
    public WebElement confirmBtn;
    @FindBy(xpath = "//p[text()='2FA Verification']/../div[2]/div/div/input")
    public WebElement otpInput;
    @FindBy(xpath = "//p[text()='2FA Verification']/../div[3]/div/button[2]")
    public WebElement otpConfirmBtn;
    @FindBy(xpath = "//span[text()='OK']/../../p")
    public WebElement sucessMsg;
    @FindBy(xpath = "//span[text()='OK']")
    public WebElement okBtn;
    @FindBy(xpath = "(//span[text()='Cards'])[2]")
    public WebElement cardTab;
    @FindBy(xpath = "//p[text()='Account Number']")
    public List<WebElement> cardCount;
    @FindBy(xpath = "//div/div[3]/div/a")
    public List<WebElement> cardTabCount;
    String totalPayable;
    String disAfPayable;
    int dis = 1;
    String Avbalance;
    String debitAmount;

    public AddCard_Page(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void addCardTabClick() {
        addCard.click();
    }

    public void upgrdCardTabClick() {
        upgrdCard.click();
    }

    //*********second tier**********
    public void cardPlasticClick() {
        cardPlastic.click();
    }

    //*********3rd tier**********

    public boolean verifycardNamePls() {
        ;
        System.out.println(cardNamePls.getText());
        if (cardNamePls.getText().equals("Plastic (+ $8)"))
            return true;
        else if (cardNamePls.getText().equals("Plastic (+ $ 8.00)"))
            return true;
        else
            return false;
    }

    public String CardPrice() {
        cardPrice = String.valueOf(Double.valueOf(collectPrice.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));
        System.out.println(cardPrice);
        return cardPrice;
    }

    //*********Ultima tier**********

    public void cardAluminiumClick() {
        cardAluminium.click();
    }

    public boolean verifycardNameAlu() {
        System.out.println(cardNameAlu.getText());
        if (cardNameAlu.getText().equals("Aluminium (+ $120)"))
            return true;
        else if (cardNameAlu.getText().equals("Aluminium (+ $ 120.00)"))
            return true;
        else
            return false;
    }

    public void cardSteelClick() {
        cardSteel.click();
    }

    public boolean verifycardNameSteel() {
        System.out.println(cardNameSteel.getText());
        if (cardNameSteel.getText().equals("Steel (+ $484)"))
            return true;
        else if (cardNameSteel.getText().equals("Steel (+ $ 484.00)"))
            return true;
        else
            return false;

    }

    public void cardAluminiumClick1() {
        cardAluminium1.click();
    }

    public boolean verifycardNameAlu1() {
        System.out.println(cardNameAlu1.getText());
        if (cardNameAlu1.getText().equals("Aluminium (+ $120)"))
            return true;
        else if (cardNameAlu1.getText().equals("Aluminium (+ $ 120.00)"))
            return true;
        else
            return false;

    }

    public void cardSteelClick1() {
        cardSteel1.click();
    }

    public boolean verifycardNameSteel1() {
        System.out.println(cardNameSteel1.getText());
        if (cardNameSteel1.getText().equals("Steel (+ $484)"))
            return true;
        else if (cardNameSteel1.getText().equals("Steel (+ $ 484.00)"))
            return true;
        else
            return false;
    }

    public void cardSteelClick2() {
        cardSteel2.click();
    }

    public boolean verifycardNameSteel2() {
        System.out.println(cardNameSteel2.getText());
        if (cardNameSteel2.getText().equals("Steel (+ $484)"))
            return true;
        else if (cardNameSteel2.getText().equals("Steel (+ $ 484.00)"))
            return true;
        else
            return false;
    }

    public boolean verifycardNameSteel3() {
        System.out.println(cardNameSteel2.getText());
        if (cardNameSteel2.getText().equals("Plastic (+ €150)"))
            return true;
        else if (cardNameSteel2.getText().equals("Plastic (+ € 150.00)"))
            return true;
        else
            return false;
    }

    public void shipDropDownClick() {
        shipDropDown.click();
    }

    public String getTextShippingMethod() {
        String shippingMethod = shipDropDown.getText();
        return shippingMethod;
    }

    public String shippingStanderPrice() {
        shippingPrice = String.valueOf(Double.valueOf(shipDropDown.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));
        return shippingPrice;
    }

    public void shippingExpedClick() {
        shippingExped.click();
    }

    public void shippingExpedClickUltima() {
        shippingExpedUltima.click();
    }

    public String shippingExpedPrice() {
        shippingPrice = String.valueOf(Double.valueOf(shipDropDown.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));
        return shippingPrice;
    }

    public String payableShippingPrice() {
        payShippingPrice = String.valueOf(Double.valueOf(payShipping.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
        System.out.println(payShippingPrice);
        return payShippingPrice;
    }

    public String payableCardPrice() {
        payableCardPrice = String.valueOf(Double.valueOf(payCard.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
        System.out.println(payableCardPrice);
        return payableCardPrice;
    }

    public String payTodayPrice() {
        payTodayPrice = String.valueOf(Double.valueOf(payToday.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
        System.out.println(payTodayPrice);
        return payTodayPrice;
    }

    public String discountRate() {
        discountRate = String.valueOf(Double.valueOf(disApply.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
        System.out.println("discount1:" + discountRate);
        return discountRate;
    }


    //Next page

    public String totalPayable() {
        totalPayable = String.valueOf(Double.valueOf(payShippingPrice) + Double.valueOf(payableCardPrice));
        System.out.println(totalPayable);
        return totalPayable;
    }

    public String disAfPayable() {
        discountRate();
        System.out.println("discount2:" + discountRate);
        System.out.println("discount2:" + totalPayable);
        DecimalFormat df = new DecimalFormat("#.##");
        String disAfPayable = df.format(Math.round((Double.valueOf(totalPayable) - Double.valueOf(discountRate)) * 100.0) / 100.0);
        System.out.println(disAfPayable);
        return disAfPayable;
    }

    public void crossBtnClick() {
        crossBtn.click();
    }

    public void discountCodeInput() {
        if (dis == 1)
            discountCode.sendKeys(UserProfile.dis1stTier);
        else if (dis == 2)
            discountCode.sendKeys(UserProfile.dis2ndTier);
        else if (dis == 3)
            discountCode.sendKeys(UserProfile.dis3rdTier);
        dis++;
    }

    public void applyBtnClick() {
        applyBtn.click();
    }

    public void paymentMethodClick() {
        paymentMethod.click();
    }

    public void paymentAccountClick() throws InterruptedException {
        paymentAccount.click();
        Thread.sleep(3000);
    }

    public void selectEwallet() throws InterruptedException {

        for (int i = 1; i <= 5; i++) {
            Thread.sleep(1000);
            Avbalance = String.valueOf(Double.valueOf(balance.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
            System.out.println("Available Balance" + Avbalance);


            if (Double.valueOf(Avbalance) >= Double.valueOf(payTodayPrice)) {
                Thread.sleep(1000);
                debitAmount = String.valueOf(Double.valueOf(debitAmt.getText().replaceAll("[A-Za-z()+$€₱円¥£\\s-]", "").substring(0)));//.substring(1)
                System.out.println("debitAmount" + debitAmount);
                if (Double.valueOf(Avbalance) >= Double.valueOf(debitAmount)) {
                    System.out.println("ok1");
                    break;
                }

            }
            System.out.println("ok2");
            Thread.sleep(2000);
            ewallet.click();
            Thread.sleep(1000);
            if (i == 1)
                selectEW2.click();
            else if (i == 2)
                selectEW3.click();
            else if (i == 3)
                selectEW4.click();
            else if (i == 4)
                selectEW5.click();

        }

    }

    public void paymentCardClick() {
        paymentCard.click();
    }

    public String shipMetNameGetText() {
        String shipMetNameGT = shipMetName.getText();
        return shipMetNameGT;
    }

    public void confirmBtnClick() {
        confirmBtn.click();
    }

    public boolean verifySucessMsg() {
        return sucessMsg.isDisplayed();
    }

    public void okBtnClick() {
        okBtn.click();
    }

    public boolean verifyCardTab() {
        return cardTab.isDisplayed();
    }

    public int cardCount() throws InterruptedException {
        int size = cardCount.size();
        System.out.println(size);
        return size;
    }

    public int cardTabCount() throws InterruptedException {
        int size = cardTabCount.size();
        System.out.println(size);
        return size;
    }

}
