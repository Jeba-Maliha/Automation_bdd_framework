package StepDefinations;

import Pages.AddCard_Page;
import Utility.Hooks;
import Utility.SmartWait;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;


public class AddCard_Step {

    public WebDriver driver;
    AddCard_Page addphycardpage;

    SmartWait smartWait = new SmartWait();
    int shipping = 1;

    public AddCard_Step() {
        this.driver = Hooks.getDriver();
        addphycardpage = new AddCard_Page(driver);
    }

    public void waitload() {
        new WebDriverWait(driver, 10).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    @When("user clicks on Add card tab")
    public void user_clicks_on_add_card_tab() throws Exception {
        Thread.sleep(2000);
        waitload();
        addphycardpage.addCardTabClick();
        waitload();
    }

    @Then("all three card with price should appear in a carousel")
    public void all_three_card_with_price_should_appear_in_a_carousel() throws Exception {
        Thread.sleep(2000);
        waitload();
        Assert.assertTrue("First tier card name doesn't match", addphycardpage.verifycardNamePls());
        waitload();
        addphycardpage.cardAluminiumClick();
        waitload();
        Assert.assertTrue("Second tier card name doesn't match", addphycardpage.verifycardNameAlu());
        waitload();
        Thread.sleep(2000);
        addphycardpage.cardSteelClick();
        waitload();
        Assert.assertTrue("Third tier card name doesn't match", addphycardpage.verifycardNameSteel());
        waitload();
        Thread.sleep(2000);
        addphycardpage.cardPlasticClick();
        waitload();
        Thread.sleep(5000);
    }

    @When("user select first tier card")
    public void user_select_first_tier_card() throws Exception {

        Thread.sleep(2000);
        waitload();
        Assert.assertTrue("First tier card name doesn't match", addphycardpage.verifycardNamePls());
        waitload();
    }

    @When("user checks paying amount with standard mail shipping")
    public void user_checks_paying_amount_with_standard_mail_shipping() throws Exception {
        Thread.sleep(2000);
        waitload();
        Assert.assertEquals("Shipping method doesn't match", "Standard Mail (Global) - (+ $5.95)", addphycardpage.getTextShippingMethod());
        waitload();
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.CardPrice(), addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingStanderPrice(), addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price doesn't match", addphycardpage.totalPayable(), addphycardpage.payTodayPrice());
    }

    @When("user checks paying amount with standard mail shipping for ultima")
    public void user_checks_paying_amount_with_standard_mail_shipping_for_ultima() throws Exception {
        Thread.sleep(5000);
        waitload();
        Assert.assertEquals("Shipping method doesn't match", "Standard Mail (Global) - (+ €5.95)", addphycardpage.getTextShippingMethod());
        waitload();
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.CardPrice(), addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingStanderPrice(), addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price doesn't match", addphycardpage.totalPayable(), addphycardpage.payTodayPrice());
    }

    @When("user checks payment and shipping summary in payment page")
    public void user_checks_payment_and_shipping_summary_in_payment_page() throws InterruptedException {
        System.out.println("Go to next page");
        Thread.sleep(2000);
        waitload();
        if (shipping == 1)
            Assert.assertEquals("Shipping method doesn't match", "Standard Mail (Global)", addphycardpage.shipMetNameGetText());
        else {
            Assert.assertEquals("Shipping method doesn't match", "Expedited", addphycardpage.shipMetNameGetText());
            shipping = 1;
        }

        waitload();
        shipping++;
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.cardPrice, addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingPrice, addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price doesn't match", addphycardpage.totalPayable(), addphycardpage.payTodayPrice);
    }

    @When("user apply discount code in payment page")
    public void user_apply_discount_code_in_payment_page() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.discountCodeInput();
        waitload();
        Thread.sleep(2000);
        addphycardpage.applyBtnClick();
        waitload();
        Thread.sleep(5000);
    }

    @When("user checks payment and shipping summary in payment page after apply discount")
    public void user_checks_payment_and_shipping_summary_in_payment_page_after_apply_discount() {
        waitload();
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.cardPrice, addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingPrice, addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price after discount code apply doesn't match", addphycardpage.payTodayPrice(), addphycardpage.disAfPayable());
        waitload();
    }

    @When("user press cross button")
    public void user_press_cross_button() {
        waitload();
        addphycardpage.crossBtnClick();
        waitload();
    }

    @When("user checks paying amount with Expedite mail shipping")
    public void user_checks_paying_amount_with_expedite_mail_shipping() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        addphycardpage.shipDropDownClick();
        waitload();
        addphycardpage.shippingExpedClick();
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Shipping method doesn't match", "Expedited - (+ $119.95)", addphycardpage.getTextShippingMethod());
        waitload();
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.CardPrice(), addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingExpedPrice(), addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price doesn't match", addphycardpage.totalPayable(), addphycardpage.payTodayPrice());
    }

    @When("user checks paying amount with Expedite mail shipping for Ultima")
    public void user_checks_paying_amount_with_expedite_mail_shipping_for_Ultima() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        addphycardpage.shipDropDownClick();
        waitload();
        addphycardpage.shippingExpedClickUltima();
        waitload();
        Thread.sleep(5000);
        Assert.assertEquals("Shipping method doesn't match", "Expedited - (+ €110.95)", addphycardpage.getTextShippingMethod());
        waitload();
        Assert.assertEquals("Payable Card price doesn't match", addphycardpage.CardPrice(), addphycardpage.payableCardPrice());
        waitload();
        Assert.assertEquals("Payable shipping price doesn't match", addphycardpage.shippingExpedPrice(), addphycardpage.payableShippingPrice());
        waitload();
        Assert.assertEquals("Pay today price doesn't match", addphycardpage.totalPayable(), addphycardpage.payTodayPrice());
    }

    @When("user selects Accounts for payment")
    public void user_selects_accounts_for_payment() throws InterruptedException {
        waitload();
        addphycardpage.paymentMethodClick();
        waitload();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        addphycardpage.paymentAccountClick();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
        waitload();
        addphycardpage.selectEwallet();
        waitload();
    }

    @When("user selects Card for payment")
    public void user_selects_card_for_payment() throws InterruptedException {
        waitload();
        addphycardpage.paymentMethodClick();
        waitload();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        addphycardpage.paymentCardClick();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
    }

    @When("user confirms payment using accounts")
    public void user_confirms_payment_using_accounts() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        addphycardpage.confirmBtnClick();
        Thread.sleep(2000);
        waitload();
    }

    @And("click on ok button with success massage")
    public void click_on_ok_button_with_success_massage() throws Exception {
        Thread.sleep(2000);
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
        addphycardpage.verifySucessMsg();
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
        addphycardpage.okBtnClick();
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
    }

    @Then("user should redirects to cards tab and one physical card with inactive status should appear")
    public void user_should_redirects_to_cards_tab_and_one_physical_card_with_inactive_status_should_appear() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.verifyCardTab();
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("one physical card doesn't show", 1, addphycardpage.cardCount());
        waitload();
    }

    @When("user clicks on Upgrade card tab")
    public void user_clicks_on_upgrade_card_tab() throws InterruptedException {
        waitload();
        Thread.sleep(1000);
        addphycardpage.upgrdCardTabClick();
        waitload();
        Thread.sleep(1000);
    }

    @Then("tier 2nd and tier 3th card with price should appear in a carousel")
    public void tier_2nd_and_tier_3th_card_with_price_should_appear_in_a_carousel() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.verifycardNameAlu1();
        waitload();
        Thread.sleep(2000);
        addphycardpage.cardSteelClick1();
        waitload();
        addphycardpage.verifycardNameSteel1();
        waitload();
        Thread.sleep(2000);
        waitload();
        addphycardpage.cardAluminiumClick1();
        Thread.sleep(2000);
    }

    @When("user select second tier card")
    public void user_select_second_tier_card() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        Assert.assertTrue("Second tier card name doesn't match", addphycardpage.verifycardNameAlu1());
        waitload();
    }

    @Then("user should redirects to cards tab and two physical card with inactive status should appear")
    public void user_should_redirects_to_cards_tab_and_two_physical_card_with_inactive_status_should_appear() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.verifyCardTab();
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Two physical card doesn't show", 2, addphycardpage.cardCount());
        waitload();
    }

    @Then("tier 3th card with price should appear in a carousel")
    public void tier_3th_card_with_price_should_appear_in_a_carousel() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        Assert.assertTrue("3rd tier card name doesn't match", addphycardpage.verifycardNameSteel2());
        waitload();
        Thread.sleep(2000);
        waitload();
        addphycardpage.cardSteelClick2();
        waitload();
    }

    @Then("Verify card with price should appear in a carousel")
    public void Verify_card_with_price_should_appear_in_a_carousel() throws InterruptedException {
        Thread.sleep(2000);
        waitload();
        Assert.assertTrue("Ultima card name doesn't match", addphycardpage.verifycardNameSteel3());
        waitload();
        Thread.sleep(2000);
        waitload();
        addphycardpage.cardSteelClick2();
        waitload();
    }

    @Then("user should redirects to cards tab and three physical card with inactive status should appear")
    public void user_should_redirects_to_cards_tab_and_three_physical_card_with_inactive_status_should_appear() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.verifyCardTab();
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Two physical card doesn't show", 3, addphycardpage.cardCount());
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Upgrade Card Tab Still showing", 2, addphycardpage.cardTabCount());
        waitload();
    }

    @Then("user should redirects to cards tab and two physical card with inactive status should appear and Upgrade Card tab should be remove")
    public void user_should_redirects_to_cards_tab_and_three_physical_card_with_inactive_status_should_appear_and_Upgrade_Card_tab_should_be_remove() throws InterruptedException {
        waitload();
        Thread.sleep(2000);
        addphycardpage.verifyCardTab();
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Two physical card doesn't show", 2, addphycardpage.cardCount());
        waitload();
        Thread.sleep(2000);
        Assert.assertEquals("Upgrade Card Tab Still showing", 2, addphycardpage.cardTabCount());
        waitload();
    }

}
